"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dao_1 = require("./models/dao");
const errors_1 = require("./models/errors");
const handler = (event, context) => __awaiter(void 0, void 0, void 0, function* () {
    console.log("putContact event:", event);
    // Check if the body is a string and parse it
    let body;
    try {
        body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    }
    catch (err) {
        console.error("Error parsing body:", err);
        return {
            statusCode: 400,
            body: JSON.stringify({
                message: "Invalid JSON format.",
            }),
        };
    }
    console.log("putContact received body:", body);
    // Destructure the fields from the body
    let { email, phoneNumber, firstName, lastName, companyName, message } = body;
    // Ensure companyName is set to null if it is undefined
    if (companyName === undefined) {
        companyName = null;
    }
    const contact = new dao_1.ContactsDao({
        email,
        phoneNumber,
        firstName,
        lastName,
        companyName,
        message,
    });
    let response = null;
    try {
        response = yield contact.putContact();
    }
    catch (error) {
        console.error(error);
        if (error instanceof errors_1.LambdaDynamoDBError) {
            return {
                statusCode: error.statusCode,
                body: JSON.stringify({
                    message: error.message,
                }),
            };
        }
    }
    if (response && response.$metadata.httpStatusCode) {
        if (response.$metadata.httpStatusCode == 200)
            return {
                statusCode: 200,
                body: JSON.stringify({
                    message: "Successfully added contact.",
                    contact: contact.toJson(),
                }),
            };
    }
    return {
        statusCode: 500,
        body: JSON.stringify({
            message: "Unknown error.",
        }),
    };
});
exports.handler = handler;
