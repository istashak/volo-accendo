"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const dao_1 = require("../../../src/models/dao");
describe("ContactDao", () => {
    test("Returning a Contacts object fro the toJson function.", () => {
        const contact = {
            email: "foo@test.com",
            phoneNumber: "(561) 867-5309",
            firstName: "Jannie",
            lastName: "Somegal",
            companyName: "Acme Inc.",
            message: "Jannie don't you lose that number!",
        };
        const contactsDao = new dao_1.ContactsDao(contact);
        expect(contactsDao.toJson()).toBe(contact);
    });
});
