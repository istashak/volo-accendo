"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDynamoDBClient = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
let client = null;
const getDynamoDBClient = () => {
    if (client)
        return client;
    client = new client_dynamodb_1.DynamoDBClient({
        region: process.env.REGION,
    });
    return client;
};
exports.getDynamoDBClient = getDynamoDBClient;
