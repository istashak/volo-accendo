"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseDao = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const errors_1 = require("../errors");
class BaseDao {
    handleDynamoDBException(exception) {
        var _a, _b, _c, _d, _e, _f;
        let statusCode;
        let message;
        // Determine the type of error and set appropriate status code and message
        if (exception instanceof client_dynamodb_1.ConditionalCheckFailedException) {
            statusCode = (_b = (_a = exception.$response) === null || _a === void 0 ? void 0 : _a.statusCode) !== null && _b !== void 0 ? _b : 400;
            message = exception.message;
        }
        else if (exception instanceof client_dynamodb_1.ProvisionedThroughputExceededException) {
            statusCode = (_d = (_c = exception.$response) === null || _c === void 0 ? void 0 : _c.statusCode) !== null && _d !== void 0 ? _d : 503;
            message = exception.message;
        }
        else if (exception instanceof client_dynamodb_1.ResourceNotFoundException) {
            statusCode = (_f = (_e = exception.$response) === null || _e === void 0 ? void 0 : _e.statusCode) !== null && _f !== void 0 ? _f : 404;
            message = exception.message;
        }
        else {
            statusCode = 500;
            message = "Internal Server Error";
        }
        return new errors_1.LambdaDynamoDBError(message, statusCode);
    }
}
exports.BaseDao = BaseDao;
