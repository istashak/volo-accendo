"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContactsDao = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const __1 = require("../../");
const base_dao_1 = require("./base-dao");
const errors_1 = require("../errors");
class ContactsDao extends base_dao_1.BaseDao {
    constructor(contact) {
        var _a;
        super();
        this.email = contact.email;
        this.phoneNumber = contact.phoneNumber;
        this.firstName = contact.firstName;
        this.lastName = contact.lastName;
        this.companyName = (_a = contact.companyName) !== null && _a !== void 0 ? _a : null;
        this.message = contact.message;
    }
    putContact() {
        return __awaiter(this, void 0, void 0, function* () {
            const params = {
                TableName: process.env.CONTACTS_TABLE_NAME,
                Item: {
                    email: { S: this.email },
                    firstName: { S: this.firstName },
                    lastName: { S: this.lastName },
                    message: { S: this.message },
                    companyName: this.companyName
                        ? { S: this.companyName }
                        : { NULL: true },
                },
            };
            try {
                const data = yield (0, __1.getDynamoDBClient)().send(new client_dynamodb_1.PutItemCommand(params));
                console.log("Success - item added or updated", data);
                return data;
            }
            catch (err) {
                console.error("Error adding or updating item", err);
                if (err instanceof Error) {
                    throw this.handleDynamoDBException(err);
                }
                else {
                    // Handle non-Error cases or throw a general error
                    throw new errors_1.LambdaDynamoDBError("Unknown error occurred", 500);
                }
            }
        });
    }
    toJson() {
        return {
            email: this.email,
            phoneNumber: this.phoneNumber,
            firstName: this.firstName,
            lastName: this.lastName,
            companyName: this.companyName,
            message: this.message,
        };
    }
}
exports.ContactsDao = ContactsDao;
