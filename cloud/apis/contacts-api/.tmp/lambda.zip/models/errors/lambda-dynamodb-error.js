"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LambdaDynamoDBError = void 0;
class LambdaDynamoDBError extends Error {
    constructor(message, statusCode) {
        super(message);
        this.statusCode = statusCode;
        this.name = "LambdaDynamoDBError";
    }
}
exports.LambdaDynamoDBError = LambdaDynamoDBError;
